#include <boost/multi_array.hpp>

#include "MediaLayer.h"
#include "RenderEngine.h"
#include "ShaderProgram.h"
#include "Mesh.h"

#define PROGRAM_NAME "Cone Step Mapping"

MediaLayer * mediaLayer;
RenderEngine * renderEngine;
Mesh * tetrahedron;

void initScene(){
	tetrahedron = new Mesh();
	vector<GLfloat> vertices = {
			1.0, 1.0, 1.0,
			-1.0, -1.0, 1.0,
			-1.0, 1.0, -1.0,
			1.0, -1.0, -1.0
	};

	vector<GLfloat> vertexColors = {
		1.0,  0.0,  0.0,
		0.0,  1.0,  0.0,
		0.0,  0.0,  1.0,
		1.0,  1.0,  1.0
	};

	vector<GLubyte> indicies = { 0, 1, 2, 3, 0, 1 };
	tetrahedron->addBuffer(vertices);
	tetrahedron->addBuffer(vertexColors);
	tetrahedron->addElementBuffer(indicies);

	renderEngine->shaderProgram->attachShader("tutorial4.vert", GL_VERTEX_SHADER);
	renderEngine->shaderProgram->attachShader("tutorial4.geom", GL_GEOMETRY_SHADER);
	renderEngine->shaderProgram->attachShader("tutorial4.frag", GL_FRAGMENT_SHADER);

    /* Bind attribute 0 (coordinates) to in_Position and attribute 1 (colors) to in_Color */
	renderEngine->shaderProgram->bindAttrib("in_Position");
	renderEngine->shaderProgram->bindAttrib("in_Color");
}

int main(int argc, char *argv[])
{

	mediaLayer = new MediaLayer(PROGRAM_NAME, 750, 750);

	renderEngine = new RenderEngine();
	initScene();
	renderEngine->shaderProgram->linkAndUse();
	mediaLayer->renderLoop(renderEngine);

    delete tetrahedron;
    delete renderEngine;
    delete mediaLayer;

}
